
package com.mycompany.aderessbook;

public class BirthDate {
    int day , month , year;
    String[] m ={"Jan" , "Feb" , "Mar" , "Apr"
     , "May" , "June" , "July" ,
     "August" , "Sep" , "Oct" , "Nov" , "Dec"};
    
    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public void setDay(int day) {
        if(day < 0 || day > 31) {
            System.out.println("InValid");
        }
        else
         this.day = day;
    }

    public void setMonth(int month) {
        if(month > 12 || month < 1) {
            System.out.println("InValid");
        }
        else
          this.month = month;
    }

    public void setYear(int year) {
          this.year = year;
    }

    String mon = "";
    public void setMon(String mon) {
        this.mon = mon;
    }

    public String getInfo () {
        for(int i = 0 ; i < 12 ; i++) {
             if(getMonth() == i+1) {
                setMon(m[i]);
                break;
            }
        }
        
        return (getDay() + " " + getMonth() + " " + getYear());

        
    }

   
    public String getAge() {
        int current_day = 14;
        int current_mon = 10;
        int current_year = 2022;
        if(getDay() > 14) {
            current_day += 30;
            current_mon--;
        }
        if(getMonth() > current_mon) {
            current_year--;
            current_mon += 12;
        }
        setYear(current_year-getYear());
        setDay(current_day-getDay());
        setMonth(current_mon-getMonth());
         
        return (getYear() + " Year\n"+ getMonth() +
         " Month\n" + getDay() + " Days\n");
    }
        public BirthDate( int day ,int month , int year) {
            this.day = day;
            this.month = month;
            this.year = year;
        }
}
