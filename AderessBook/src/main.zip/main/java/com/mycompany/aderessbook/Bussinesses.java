
package com.mycompany.aderessbook;

public class Bussinesses extends Data{

    private String Title;
    private String Genre;
    private String Wibsite;
    private String ContactPerson;
    ///getter

    public String getTitle() {
        return Title;
    }

    public String getGenre() {
        return Genre;
    }

    public String getWibsite() {
        return Wibsite;
    }

    public String getContactPerson() {
        return ContactPerson;
    }
    //setter

    public boolean setTitle(String Title) {
        boolean flag = Title.trim().length() != 0;
        if (flag) {
            return false;
        } else {
            this.Title = Title;
            return true;
        }

    }

    public boolean setGenre(String Genre) {
        boolean flag = (Genre.trim().length() != 0);
        if (flag) {
            return false;
        } else {
            this.Genre = Genre;
            return true;
        }
    }

    public boolean setWibsite(String Wibsite) {
        boolean flag = (Wibsite.trim().length() != 0);
        if (flag) {
            return false;
        } else {
            this.Wibsite = Wibsite;
            return true;
        }
    }

    public boolean setContactPerson(String ContactPerson) {

        boolean flag = (ContactPerson.trim().length() != 0);
        if (flag) {
            return false;
        } else {
            this.ContactPerson = ContactPerson;
            return true;
        }
    }
   
    @Override
    public String getInfo(){

        return 
                "The Title is : " +
                this.Title + "\nThe Genre: " +
                this.Genre + "\nThe Wibsite : " + 
                this.Wibsite + "\nContactPerson : " +
                this.ContactPerson + 
                " " +super.getInfo() ;

    }

}
