
package com.mycompany.aderessbook;

public class Data {
    private String country ;
    private String city ;
    private String postal ;
    private String email ;
    private String telNum ;

    Data () {
    // intialize
    }
    Data (String countrt , String city , String email , String postsal , String telNum) {
        this.country = countrt ;
        this.city = city ;
        this.email = email ;
        this.postal = postsal ;
        this.telNum = telNum ;
    }
    public String getCoutry () {
        return this.country ;
    }
    public String getCity () {
        return this.city ;
    }
    public String getEmail () {
        return this.email ;
    }
    public String getPostal () {
        return this.postal ;
    }
    public String getTelNum  () {
        return this.telNum ;
    }
    
    public boolean setCity(String city) {
        if (city.trim().length() != 0) {
            this.city = city;
            return true ;
        } else {
            return false ;
        }
    }
    
    public boolean setCountry(String country) {
        if (country.trim().length() != 0) {
            this.country = country;
            return true ;
        } else {
            return false ;
        }
    }
    public boolean setEmail(String email) {
        if (email.contains("@") && email.contains(".") && email.indexOf("@") < email.indexOf(".")) {
            this.email = email;
            return true ;
        } else {
            return false ;
        }
    }public boolean setPostal(String postal) {
        if (postal.length() == 4) {
            this.postal = postal;
            return true ;
        } else {
            return false ;
        }
    }
    public boolean setTelNum(String telNum) {
        if (telNum.length() == 10) {
            this.telNum = telNum;
            return true ;
        } else {
            return false ;
        }
    }

    //must be completed as soon as posible

    public String getInfo () {
        return ("email : " +  this.email + " telephone number: " + this.telNum + "country : " + this.country + " city : " + this.city + " postal code: " + this.postal) ;
    }
}
