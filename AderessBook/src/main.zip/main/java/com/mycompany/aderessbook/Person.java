/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aderessbook;

/**
 *
 * @author smart
 */
public class Person extends Data {
    private String firstName;
    private String lastName ;
    public BirthDate bd;
    
    public String getFirst() {
        return firstName;
    }
    
     public String getLast() {
        return lastName;
    }
     
     public boolean setFirst(String firstName) {
         
         for(int i=0; i < firstName.length(); i++) {
            Boolean flag = Character.isDigit(firstName.charAt(i));
            if(flag) {
               return false;
            } 
         }
            this.firstName = firstName;
            return true;
      }
     
      public boolean setLast(String lastName) {
          
        for(int i=0; i < firstName.length(); i++) {
            Boolean flag = Character.isDigit(firstName.charAt(i));
            if(flag) {
               return false;
            } 
        }
        this.lastName = lastName;
        return true;
    }
    
    @Override
    public String getInfo() {
        return "Person Name : " + firstName + " " + lastName + '\n' 
                + bd.getInfo() + " " + super.getInfo() ;
    }
    
}
